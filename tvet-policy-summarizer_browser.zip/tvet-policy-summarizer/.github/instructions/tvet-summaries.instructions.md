---
applyTo: "output/**/*.md"
---
Files in `output/` are TVET policy summaries. When creating or editing them:
- Keep the exact template of `examples/example-summary.md` (title, metadata table, Summary, Keywords, footer).
- Summary section: maximum 80 words, one paragraph, English, neutral, third person, no evaluation.
- Use `Not stated` for missing metadata. Never invent facts.
- Update the word count in the footer after every edit.
