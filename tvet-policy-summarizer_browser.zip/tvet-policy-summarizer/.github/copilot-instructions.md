# Copilot instructions: TVET policy summaries

This workspace produces standardised summaries of Technical and Vocational Education and Training
(TVET) policy documents. Apply these instructions to every chat, edit and agent request here.

## Workspace layout
- `input/` - source PDF files. Read-only: never edit, rename, move or delete them.
- `work/extracted/` - plain text of each PDF, created by `python -m harness extract`.
- `output/` - one summary per PDF, named `<pdf name without .pdf>.summary.md`.
- `prompts/style-guide.md` - the full, authoritative style guide.
- `examples/example-summary.md` - reference output.
- `agents/`, `harness/`, `config/` - offline pipeline with local Ollama models. Do not change unless asked.

## Workflow for summarising documents
1. If `work/extracted/<name>.txt` is missing, run in the terminal:
   `.venv\Scripts\python.exe -m harness extract` (Windows) or `python -m harness extract`.
2. Read the extracted text completely. Base the summary only on that text.
3. Write `output/<name>.summary.md` using the template below. Do not overwrite existing summaries
   unless the user asks for it.
4. Run `.venv\Scripts\python.exe -m harness validate output/<name>.summary.md` and fix every error.

## Summary rules (mandatory)
- The Summary section has at most **80 words**: one paragraph, complete sentences, no bullet points.
- English, British spelling, regardless of the source language.
- Neutral and factual, third person, present tense for what the document does.
- Describe only. No praise, criticism, recommendations, speculation or outside knowledge.
- No evaluative words (for example groundbreaking, ambitious, excellent, crucial, comprehensive, robust).
- Recommended order: document type, issuer, country/region, year and scope; main objectives;
  key measures; target groups, governance, funding or timeframe where stated.
- Metadata that is not in the document is written as `Not stated`.
- 3 to 5 lowercase keywords separated by semicolons.

## Output template

```
# <Official title> [English translation if the title is not in English]

| Field | Value |
|---|---|
| Source file | <file name>.pdf |
| Issuing body | <...> |
| Country / region | <...> |
| Year | <...> |
| Document type | <...> |

## Summary

<one neutral paragraph, maximum 80 words>

## Keywords

<keyword>; <keyword>; <keyword>

---

*Word count: <n>/80 | Generated: <YYYY-MM-DD> | Agent: GitHub Copilot | Model: <model>*
```

## Answers in chat
When asked about a document in chat without writing a file, still keep summaries within 80 words
and in the same neutral style.
