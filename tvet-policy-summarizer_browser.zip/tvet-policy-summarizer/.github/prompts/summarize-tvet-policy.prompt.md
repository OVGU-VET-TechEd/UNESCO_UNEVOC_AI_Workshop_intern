---
description: Summarise TVET policy PDFs from input/ into the standard 80-word format
agent: agent
---
Summarise the TVET policy documents in `input/` following `.github/copilot-instructions.md`
and `prompts/style-guide.md`.

Steps:
1. Run `.venv\Scripts\python.exe -m harness extract` in the terminal (use `python -m harness extract`
   on macOS/Linux) unless `work/extracted/` already contains a text file for every PDF.
2. For each text file in `work/extracted/` without a matching `output/<name>.summary.md`
   (or only for ${input:files:all or specific file names}), read the full text.
3. Write `output/<name>.summary.md` exactly in the template from the instructions,
   using `examples/example-summary.md` as the model. Maximum 80 words in the Summary section.
4. Run `.venv\Scripts\python.exe -m harness validate` and correct every reported error.
5. Report a short table: file, word count, validation result.
