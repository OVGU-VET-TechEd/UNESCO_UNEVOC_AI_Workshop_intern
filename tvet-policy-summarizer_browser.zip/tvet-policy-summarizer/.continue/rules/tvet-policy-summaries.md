---
name: TVET policy summary standard
description: Format and neutral style for TVET policy summaries (max. 80 words)
alwaysApply: true
---
When summarising TVET policy documents in this workspace:
- Use the template in `examples/example-summary.md` and the rules in `prompts/style-guide.md`.
- Summary section: maximum 80 words, one paragraph, English, neutral and factual, third person.
- No praise, criticism, recommendations, speculation or outside knowledge.
- Write `Not stated` for missing metadata; 3 to 5 lowercase keywords separated by semicolons.
- Work from `work/extracted/*.txt` (create with `python -m harness extract`); never modify `input/`.
- Save results as `output/<pdf name>.summary.md` and check them with `python -m harness validate`.
