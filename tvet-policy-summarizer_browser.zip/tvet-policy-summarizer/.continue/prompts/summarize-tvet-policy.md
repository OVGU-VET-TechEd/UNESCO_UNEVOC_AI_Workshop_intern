---
name: summarize-tvet-policy
description: Summarise the attached TVET policy text in the standard 80-word format
invokable: true
---
Summarise the attached TVET policy document text (from `work/extracted/`) using the workspace rules.

Output only the Markdown record in this exact structure:
- `# <Official title>`
- metadata table with rows: Source file, Issuing body, Country / region, Year, Document type
- `## Summary` with one neutral paragraph of at most 80 words
- `## Keywords` with 3 to 5 lowercase keywords separated by semicolons
- footer line: `*Word count: <n>/80 | Generated: <date> | Agent: Continue | Model: <model>*`

Use only information from the text. Write `Not stated` for missing metadata.
