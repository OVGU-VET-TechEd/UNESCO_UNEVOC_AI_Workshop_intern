from harness.cli import main

raise SystemExit(main())
