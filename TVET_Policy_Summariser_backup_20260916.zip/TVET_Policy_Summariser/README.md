# TVET Policy Summariser

Standardised summaries of TVET policy PDFs: **English, neutral style, maximum 80 words**,
same Markdown format for every document - produced either with **GitHub Copilot** or **fully offline**
with small local models (Ollama).

## Quick start

1. Copy policy PDFs into `input/` (subfolders are allowed, e.g. `input/Kenya/`).
2. Choose a workflow:

| Workflow | Internet / account | How |
|---|---|---|
| A. Offline agent harness (batch) | none after setup | `./run.sh` (Windows: `run.bat`) |
| B. GitHub Copilot in VS Code | Copilot licence | Chat: `/summarise-tvet-policy` or agent "TVET Policy Summariser" |
| C. Microsoft 365 Copilot | M365 Copilot licence | paste `copilot/m365-copilot-agent-instructions.md` into an agent |
| D. Ollama chat (single document) | none | `ollama run tvet-summariser` and paste the text |
| E. Continue (VS Code, offline) | none | install Continue extension; models/rules in `.continue/` |

3. Check results: `./run.sh --validate` -> checks every `output/*_summary.md` (from any workflow)
   and writes `output/summaries_index.csv` (opens in Excel).

## A. Offline agent harness

```
./run.sh --check                 # Ollama running? models installed? PDF library?
./run.sh                         # summarise all PDFs in input/ that have no summary yet
./run.sh --file input/x.pdf      # one document
./run.sh --model gemma3:1b       # faster, lower quality
./run.sh --force                 # redo existing summaries
./run.sh --list-agents
```

Each PDF goes through three agents (see `agents/README.md`):
`chunk-reader` (long documents only) -> `tvet-summariser` -> `style-reviewer`.
Word limit, flagged evaluative terms, pronouns, English and format are then checked **in code**.
If a problem remains, the footer says `Status: NEEDS HUMAN REVIEW - <reason>`.

Logs: `logs/run_*.log`; every prompt and model answer: `logs/run_*_agents.jsonl`.

## B. GitHub Copilot (VS Code)

Open this folder in VS Code. Copilot automatically reads:
- `.github/copilot-instructions.md` - house style, output format, workflow
- `.github/prompts/summarise-tvet-policy.prompt.md` - type `/summarise-tvet-policy` in Chat
- `.github/agents/tvet-policy-summariser.agent.md` - pick "TVET Policy Summariser" in the agent dropdown
- `.github/instructions/tvet-summaries.instructions.md` - rules for files in `output/`
- `AGENTS.md` - generic agent instructions

Copilot cannot always read PDFs. Run `./run.sh --extract-only` first; the text is written to `work/extracted/`.
Use Copilot in **Agent** mode so it can save files and run the validator.
Copilot Chat can also use the local models: model picker -> "Manage Models" -> Ollama.

## Models

Installed by the setup script (stored by Ollama, not in this folder):
- `llama3.2:3b`
- `gemma3:1b`
- `tvet-summariser` - custom model built from `ollama/Modelfile` on top of `llama3.2:3b`

Rough guide: 1B models need ~2 GB free RAM, 3B models ~4 GB. Other good small options:
`qwen2.5:3b`, `phi4-mini`, `gemma3:4b`. Pull with `ollama pull <model>` and set
`default_model` in `config/settings.json` or use `--model`.
Small models make mistakes: always check summaries marked NEEDS HUMAN REVIEW and spot-check the others.

## Folder structure

```
TVET_Policy_Summariser/
|-- input/                      PDFs to summarise
|-- output/                     <name>_summary.md + summaries_index.csv
|-- work/extracted/             extracted PDF text (created on demand)
|-- logs/                       run logs and agent traces
|-- agents/                     agent definitions (*.agent.md) + template
|-- config/                     settings.json, style_guide.md
|-- templates/                  summary_template.md (output format)
|-- harness/run_harness.py      offline pipeline (Ollama)
|-- ollama/Modelfile            custom offline model
|-- .github/                    Copilot instructions, prompt file, custom agent
|-- .continue/                  Continue.dev models, rules, prompt (offline)
|-- .vscode/settings.json       enables Copilot instruction/prompt files
|-- copilot/                    Microsoft 365 Copilot agent instructions
|-- AGENTS.md                   generic instructions for AI assistants
|-- run.sh / run.bat            launchers (use .venv if present)
`-- requirements.txt            pypdf
```

## Changing the rules
- Word limit, language, models, pipeline: `config/settings.json`
- Style rules: `config/style_guide.md` (offline harness) - copy changes into the Copilot/Continue files
  (see `config/README.md`)
- Output format: `templates/summary_template.md` - keep headings/table labels, the validator parses them

## Troubleshooting
| Problem | Fix |
|---|---|
| `Cannot reach Ollama` | start the Ollama app or run `ollama serve` |
| `Model(s) not installed` | `ollama pull llama3.2:3b` |
| `probably scanned` | OCR the PDF first, e.g. `ocrmypdf in.pdf out.pdf`, then put `out.pdf` in `input/` |
| very slow | use `--model gemma3:1b`, set `review_mode` to `on_fail`, close other apps |
| no PDF library | `.venv/bin/pip install pypdf` or `pip install pypdf` |

The sample PDF `input/_sample_fictional_tvet_policy.pdf` is fictional and only for testing - delete it before real runs.
