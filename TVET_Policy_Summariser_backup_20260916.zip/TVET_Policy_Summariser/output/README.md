# output

One `<pdf name>_summary.md` per PDF (format: `templates/summary_template.md`) and
`summaries_index.csv` with all summaries. Check with `./run.sh --validate`.
