# input

Put TVET policy PDFs here. Subfolders are allowed (e.g. `input/Kenya/`); the same subfolders are
created in `output/`. Scanned PDFs need OCR first (e.g. `ocrmypdf in.pdf out.pdf`).
