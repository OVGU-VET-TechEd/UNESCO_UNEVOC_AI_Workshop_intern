#!/usr/bin/env sh
# Launcher for the offline harness. Uses the project virtual environment if present.
cd "$(dirname "$0")" || exit 1
if [ -x .venv/bin/python ]; then PY=.venv/bin/python; else PY=python3; fi
exec "$PY" harness/run_harness.py "$@"
