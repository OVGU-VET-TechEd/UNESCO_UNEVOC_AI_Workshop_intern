---
name: summarise-tvet-policy
description: Summarise the selected TVET policy text in the standard format
invokable: true
---
Summarise the provided TVET policy document text following the rule "TVET policy summary style":
neutral, third person, English, one paragraph, at most 80 words, exact output format.
Use only the provided text.
