# Agents

Each `*.agent.md` file defines one agent: YAML-style front matter (settings) plus a
Markdown body (the system prompt). The harness (`harness/run_harness.py`) loads them all.

| Agent | Role | Input | Output |
|---|---|---|---|
| `chunk-reader` | notes | one section of a long PDF | bullet notes (text) |
| `tvet-summariser` | summariser | full text or notes | JSON: metadata, summary, keywords |
| `style-reviewer` | reviewer | source, draft, check findings | corrected JSON |

Flow per PDF:

```
PDF -> text -> [chunk-reader per section, only for long documents]
    -> tvet-summariser -> automatic checks -> style-reviewer (loop) -> output/<name>_summary.md
```

## Define or change an agent
1. Copy `_template.agent.md.example` to `agents/<name>.agent.md`.
2. Edit the front matter (`model`, `temperature`, ...) and the prompt.
3. Point a pipeline role to it in `config/settings.json` -> `"pipeline"`.
4. Check: `python harness/run_harness.py --list-agents`.

Placeholders: `{{MAX_WORDS}}`, `{{LANGUAGE}}`, `{{STYLE_GUIDE}}` (= `config/style_guide.md`).
The automatic checks (word limit, flagged terms, English, format) always run in code,
so the house rules are enforced even if a small model ignores part of its prompt.
