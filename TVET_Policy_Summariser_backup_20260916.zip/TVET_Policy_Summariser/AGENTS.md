# AGENTS.md

Instructions for any AI coding assistant working in this repository (Codex, Cursor, Gemini CLI,
Claude Code, GitHub Copilot agent mode, Continue, ...). Tool-specific files point here or repeat these rules.

## Purpose
Produce standardised summaries of TVET policy PDFs: English, neutral, at most 80 words.

## Project layout
- `input/` - policy PDFs (read-only for agents)
- `output/` - one `<pdf name>_summary.md` per PDF, plus `summaries_index.csv`
- `work/extracted/` - plain text extracted from the PDFs
- `agents/` - agent definitions for the offline harness (`*.agent.md`)
- `config/settings.json` - models, word limit, pipeline; `config/style_guide.md` - house style
- `templates/summary_template.md` - output format
- `harness/run_harness.py` - offline pipeline with Ollama

## Commands
- Summarise all new PDFs offline: `./run.sh` (Windows: `run.bat`)
- Extract text only: `./run.sh --extract-only`
- Validate summaries: `./run.sh --validate`
- Check setup: `./run.sh --check`

## Rules for summaries
- Follow `config/style_guide.md` (maximum 80 words) and `templates/summary_template.md` exactly.
- Base every statement on the document; never add outside knowledge.
- Always run `./run.sh --validate` after writing or editing a summary.
- Never modify files in `input/`.
