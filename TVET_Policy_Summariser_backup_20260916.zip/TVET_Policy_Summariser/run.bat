@echo off
rem Launcher for the offline harness. Uses the project virtual environment if present.
cd /d "%~dp0"
if exist .venv\Scripts\python.exe (set PY=.venv\Scripts\python.exe) else (set PY=python)
"%PY%" harness\run_harness.py %*
