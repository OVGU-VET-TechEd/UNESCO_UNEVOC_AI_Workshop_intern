# {{title}}

| Field | Value |
|---|---|
| Source file | {{source_file}} |
| Issuing body | {{issuing_body}} |
| Country/Region | {{country_or_region}} |
| Year | {{year}} |
| Document type | {{document_type}} |

## Summary

{{summary}}

## Keywords

{{keywords}}

---

Word count: {{word_count}}/{{max_words}} | Generated: {{generated}} | Method: {{method}} | Status: {{status}}
