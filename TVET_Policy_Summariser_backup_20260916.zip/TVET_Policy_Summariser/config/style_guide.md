<!-- Placeholders {{MAX_WORDS}} and {{LANGUAGE}} are filled from config/settings.json by the harness. -->
# House style: TVET policy summaries

## Format
- Length: maximum {{MAX_WORDS}} words (hard limit). Aim for 60 to {{MAX_WORDS}} words.
- One paragraph of continuous prose. No bullet points, headings, quotations or line breaks.
- Language: {{LANGUAGE}}. Translate content from documents written in other languages.

## Content (in this order)
1. What the document is: document type, issuing body, country or region, year.
2. Its main purpose or objective.
3. The key measures, instruments or reforms.
4. The main target groups and, if stated, the timeframe or quantified targets.

## Style
- Neutral and factual. Describe; do not evaluate.
- Third person and present tense: "The strategy aims to ...", "The act establishes ...".
- Attribute intentions and claims to the document: "The policy states ...", "It plans to ...".
- No evaluative or promotional words (e.g. excellent, ambitious, innovative, successful, weak, unfortunately, clearly).
- No recommendations, opinions, speculation or information from outside the document.
- No first or second person (I, we, our, you).
- Write out abbreviations at first use, except TVET (Technical and Vocational Education and Training).
- Keep names, numbers and dates exactly as in the document.

## Recommended opening
"The [year] [document type] by [issuing body] ([country or region]) ..." - leave out elements that are not stated.

## Example (fictional document)
The 2024 National TVET Strategy by the Ministry of Labour of Examplestan sets out a framework to align vocational training with labour market needs. It introduces a competency-based qualifications framework, expands work-based learning with employers and creates a national TVET quality assurance agency. The strategy targets young people, adult workers and women in rural areas and sets a target of 50,000 apprenticeships by 2030.
