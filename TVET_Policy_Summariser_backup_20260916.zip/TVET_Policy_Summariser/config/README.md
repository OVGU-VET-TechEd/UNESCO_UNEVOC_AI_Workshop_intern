# Configuration

## settings.json
| Key | Meaning |
|---|---|
| `ollama_host` | Ollama server URL |
| `default_model` | model for all agents with `model: default` |
| `language`, `max_words`, `min_words` | summary rules (also used in agent prompts) |
| `input_dir`, `output_dir`, `work_dir`, `log_dir`, `template` | paths relative to the project folder |
| `pipeline` | which agent file (by `name`) fills each role |
| `review_mode` | `always` (reviewer checks every draft), `on_fail` (only when checks fail), `never` |
| `max_revisions` | maximum review rounds per document |
| `chunk_chars` | documents longer than this are read section by section (notes first) |
| `max_chunks` | maximum sections read per document (spread evenly over the document) |
| `title_excerpt_chars` | characters of the first pages given to the summariser for metadata |
| `review_source_chars` | characters of source material shown to the reviewer |
| `min_text_chars` | below this, a PDF is treated as scanned (needs OCR) |
| `request_timeout_s` | timeout per model call |
| `flag_terms` | words treated as non-neutral by the automatic check |

## style_guide.md
House style inserted into agent prompts via `{{STYLE_GUIDE}}`.

**Keep in sync:** Copilot, Continue, Microsoft 365 and Modelfile instructions contain a copy of the
style guide with the limit written out (80 words). If you change the rules or `max_words`,
update `.github/`, `.continue/`, `copilot/` and `ollama/Modelfile` as well, or rerun the setup
script with `--force` after changing `MAX_WORDS`/`STYLE_GUIDE` in it.
