#!/usr/bin/env python3
"""
TVET Policy Summariser - offline agent harness (Ollama, no cloud).

Pipeline for every PDF in input/:
  1. Extract text (pypdf, pdfplumber, PyPDF2 or pdftotext)
  2. Long documents: agent "chunk-reader" writes factual notes per section
  3. Agent "tvet-summariser" writes a structured JSON draft
  4. Automatic checks: word limit, neutral wording, English, format
  5. Agent "style-reviewer" revises the draft (review_mode: always | on_fail | never)
  6. output/<name>_summary.md is written from templates/summary_template.md
     and output/summaries_index.csv is updated

Agents are plain Markdown files in agents/*.agent.md (front matter + system prompt).
Settings are in config/settings.json.

Usage (from the project folder, or use ./run.sh / run.bat):
  python harness/run_harness.py                     summarise all new PDFs in input/
  python harness/run_harness.py --file input/a.pdf  summarise selected PDFs
  python harness/run_harness.py --model gemma3:1b   use another model for all agents
  python harness/run_harness.py --force             overwrite existing summaries
  python harness/run_harness.py --extract-only      only write work/extracted/*.txt (e.g. for Copilot)
  python harness/run_harness.py --validate          check all summaries in output/ (any author)
  python harness/run_harness.py --check             check Ollama, models and PDF libraries
  python harness/run_harness.py --list-agents       show the defined agents
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import logging
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
log = logging.getLogger("harness")

SUMMARY_FIELDS = ["title", "issuing_body", "country_or_region", "year", "document_type", "summary", "keywords"]
SUMMARY_SCHEMA = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "issuing_body": {"type": "string"},
        "country_or_region": {"type": "string"},
        "year": {"type": "string"},
        "document_type": {"type": "string"},
        "summary": {"type": "string"},
        "keywords": {"type": "array", "items": {"type": "string"}},
    },
    "required": SUMMARY_FIELDS,
}
# Rows of the metadata table in templates/summary_template.md
TABLE_FIELDS = [
    ("source_file", "Source file"),
    ("issuing_body", "Issuing body"),
    ("country_or_region", "Country/Region"),
    ("year", "Year"),
    ("document_type", "Document type"),
]
PRONOUNS = re.compile(r"\b(I|We|we|Our|our|us|You|you|Your|your)\b")
ENGLISH_MARKERS = {"the", "and", "of", "to", "in", "for", "is", "on", "with", "by", "a", "an",
                   "as", "at", "from", "that", "this", "are", "it", "its"}


class ScannedPdfError(RuntimeError):
    pass


# ----------------------------------------------------------------------------- settings & agents

def load_settings() -> dict:
    return json.loads((ROOT / "config" / "settings.json").read_text(encoding="utf-8"))


def fill_placeholders(text: str, settings: dict) -> str:
    return text.replace("{{MAX_WORDS}}", str(settings["max_words"])).replace("{{LANGUAGE}}", settings["language"])


@dataclass
class Agent:
    name: str
    role: str
    description: str
    model: str
    temperature: float
    num_ctx: int
    output: str  # "json" or "text"
    system_prompt: str
    path: Path


def load_agents(settings: dict) -> dict:
    style_guide = (ROOT / "config" / "style_guide.md").read_text(encoding="utf-8")
    style_guide = re.sub(r"<!--.*?-->\s*", "", style_guide, flags=re.S)
    agents = {}
    for path in sorted((ROOT / "agents").glob("*.agent.md")):
        raw = path.read_text(encoding="utf-8")
        meta, body = {}, raw
        match = re.match(r"^---\s*\n(.*?)\n---\s*\n?(.*)$", raw, re.S)
        if match:
            for line in match.group(1).splitlines():
                if ":" in line and not line.lstrip().startswith("#"):
                    key, value = line.split(":", 1)
                    meta[key.strip()] = value.strip().strip("\"'")
            body = match.group(2)
        model = meta.get("model", "default")
        agent = Agent(
            name=meta.get("name") or path.name[: -len(".agent.md")],
            role=meta.get("role", ""),
            description=fill_placeholders(meta.get("description", ""), settings),
            model=settings["default_model"] if model in ("", "default") else model,
            temperature=float(meta.get("temperature", 0.2)),
            num_ctx=int(meta.get("num_ctx", 8192)),
            output=meta.get("output", "text"),
            system_prompt=fill_placeholders(body.replace("{{STYLE_GUIDE}}", style_guide), settings).strip(),
            path=path,
        )
        agents[agent.name] = agent
    return agents


# ----------------------------------------------------------------------------- Ollama client

class OllamaClient:
    def __init__(self, host: str, timeout: int, trace_path: Path | None = None):
        self.host = host.rstrip("/")
        self.timeout = timeout
        self.trace_path = trace_path

    def _call(self, path: str, payload: dict | None = None, timeout: int | None = None) -> dict:
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        request = urllib.request.Request(self.host + path, data=data, headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(request, timeout=timeout or self.timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "replace")
            raise RuntimeError(f"Ollama error {exc.code} on {path}: {detail}") from exc
        except urllib.error.URLError as exc:
            raise ConnectionError(
                f"Cannot reach Ollama at {self.host} ({exc.reason}). Start it with 'ollama serve' "
                "or open the Ollama app.") from exc

    def version(self) -> str:
        return self._call("/api/version", timeout=5).get("version", "?")

    def models(self) -> list:
        return [m["name"] for m in self._call("/api/tags", timeout=10).get("models", [])]

    @staticmethod
    def has_model(name: str, available: list) -> bool:
        return name in available or f"{name}:latest" in available

    def chat(self, agent: Agent, prompt: str, context: str = "", schema: dict | None = None) -> str:
        payload = {
            "model": agent.model,
            "stream": False,
            "messages": [
                {"role": "system", "content": agent.system_prompt},
                {"role": "user", "content": prompt},
            ],
            "options": {"temperature": agent.temperature, "num_ctx": agent.num_ctx},
        }
        if agent.output == "json":
            payload["format"] = schema or "json"
        started = time.time()
        content = self._call("/api/chat", payload).get("message", {}).get("content", "")
        if self.trace_path:  # full record of every agent call, for transparency
            with open(self.trace_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps({
                    "time": dt.datetime.now().isoformat(timespec="seconds"),
                    "context": context,
                    "agent": agent.name,
                    "model": agent.model,
                    "seconds": round(time.time() - started, 1),
                    "prompt": prompt,
                    "response": content,
                }, ensure_ascii=False) + "\n")
        return content


# ----------------------------------------------------------------------------- PDF text

def extract_pdf_text(pdf: Path) -> tuple:
    errors = []
    try:
        from pypdf import PdfReader
        return "\n\n".join((page.extract_text() or "") for page in PdfReader(str(pdf)).pages), "pypdf"
    except ImportError:
        errors.append("pypdf not installed")
    except Exception as exc:  # damaged or unusual PDFs: try the next extractor
        errors.append(f"pypdf: {exc}")
    try:
        import pdfplumber
        with pdfplumber.open(str(pdf)) as doc:
            return "\n\n".join((page.extract_text() or "") for page in doc.pages), "pdfplumber"
    except ImportError:
        errors.append("pdfplumber not installed")
    except Exception as exc:
        errors.append(f"pdfplumber: {exc}")
    try:
        from PyPDF2 import PdfReader as LegacyReader
        return "\n\n".join((page.extract_text() or "") for page in LegacyReader(str(pdf)).pages), "PyPDF2"
    except ImportError:
        errors.append("PyPDF2 not installed")
    except Exception as exc:
        errors.append(f"PyPDF2: {exc}")
    if shutil.which("pdftotext"):
        result = subprocess.run(["pdftotext", "-layout", str(pdf), "-"], capture_output=True, text=True)
        if result.returncode == 0:
            return result.stdout, "pdftotext"
        errors.append(f"pdftotext: {result.stderr.strip()}")
    raise RuntimeError("No PDF text extractor worked (" + "; ".join(errors) + "). Run: pip install pypdf")


def clean_text(text: str) -> str:
    text = text.replace("\x00", "")
    text = re.sub(r"(\w)-\n(\w)", r"\1\2", text)  # join words hyphenated across lines
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n\s*\n\s*(\n\s*)+", "\n\n", text)
    return text.strip()


def split_chunks(text: str, size: int, overlap: int = 300) -> list:
    chunks, start = [], 0
    while start < len(text):
        end = min(len(text), start + size)
        if end < len(text):  # prefer to cut at a paragraph or sentence boundary
            cut = text.rfind("\n\n", start + size // 2, end)
            if cut == -1:
                cut = text.rfind(". ", start + size // 2, end)
            if cut != -1:
                end = cut + 1
        chunks.append(text[start:end].strip())
        if end >= len(text):
            break
        start = max(end - overlap, start + 1)
    return [c for c in chunks if c]


def select_chunks(chunks: list, max_chunks: int) -> list:
    """Keep evenly spread chunks (always the first and last) when a document is very long."""
    max_chunks = max(2, max_chunks)
    if len(chunks) <= max_chunks:
        return chunks
    step = (len(chunks) - 1) / (max_chunks - 1)
    return [chunks[round(i * step)] for i in range(max_chunks)]


# ----------------------------------------------------------------------------- checks

def word_count(text: str) -> int:
    return len(text.split())


def normalise(data: dict) -> dict:
    result = {}
    for key in SUMMARY_FIELDS:
        if key == "keywords":
            keywords = data.get("keywords") or []
            if isinstance(keywords, str):
                keywords = re.split(r"[;,]", keywords)
            result["keywords"] = [" ".join(str(k).split()) for k in keywords if str(k).strip()][:5]
        elif key == "summary":
            result["summary"] = " ".join(str(data.get("summary") or "").split())
        else:
            value = " ".join(str(data.get(key) or "").split())
            result[key] = value or "Not stated"
    return result


def check_summary(data: dict, settings: dict) -> list:
    """Deterministic style checks. Returns a list of problems (empty list = passed)."""
    problems = []
    summary = data.get("summary") or ""
    n = word_count(summary)
    if not summary:
        return ["The summary is empty."]
    if n > settings["max_words"]:
        problems.append(f"The summary has {n} words; the maximum is {settings['max_words']}. Shorten it.")
    if n < settings.get("min_words", 0):
        problems.append(f"The summary has only {n} words; include the main objective, key measures and target groups.")
    if re.search(r"(^|\s)[•▪]\s|^\s*[-*]\s", summary):
        problems.append("Write one paragraph of prose, not a list.")
    if "!" in summary or "?" in summary:
        problems.append("Remove exclamation and question marks.")
    flagged = sorted({t for t in settings.get("flag_terms", []) if re.search(rf"\b{re.escape(t)}\b", summary, re.I)})
    if flagged:
        problems.append("Replace evaluative or non-neutral wording: " + ", ".join(flagged) + ".")
    pronouns = sorted(set(PRONOUNS.findall(summary)))
    if pronouns:
        problems.append("Use third person only; remove: " + ", ".join(pronouns) + ".")
    if settings.get("language", "English").lower() == "english":
        tokens = re.findall(r"[a-z]+", summary.lower())
        if len(tokens) >= 15 and sum(t in ENGLISH_MARKERS for t in tokens) / len(tokens) < 0.08:
            problems.append("The summary does not appear to be written in English.")
    return problems


def truncate_words(text: str, max_words: int) -> str:
    words = text.split()
    if len(words) <= max_words:
        return text
    cut = " ".join(words[:max_words])
    end = cut.rfind(".")
    return cut[: end + 1] if end > len(cut) // 2 else cut.rstrip(",;:") + "."


# ----------------------------------------------------------------------------- output

def render_summary(data: dict, settings: dict, source_file: str, method: str, status: str) -> str:
    template = (ROOT / settings["template"]).read_text(encoding="utf-8")
    values = dict(data)
    values.update(
        source_file=source_file,
        keywords="; ".join(data["keywords"]) or "Not stated",
        word_count=word_count(data["summary"]),
        max_words=settings["max_words"],
        generated=dt.date.today().isoformat(),
        method=method,
        status=status,
    )
    table_keys = {key for key, _ in TABLE_FIELDS}
    for key, value in values.items():
        value = str(value)
        if key in table_keys:
            value = value.replace("|", "/")
        template = template.replace("{{" + key + "}}", value)
    return template


def _section(text: str, heading: str):
    match = re.search(r"^##\s+" + re.escape(heading) + r"\s*$(.*?)(?=^##\s|^---\s*$|\Z)", text, re.M | re.S)
    return " ".join(match.group(1).split()) if match else None


def parse_summary_file(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    title = re.search(r"^#\s+(.+?)\s*$", text, re.M)
    data = {"file": str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),
            "title": title.group(1) if title else None}
    for key, label in TABLE_FIELDS:
        row = re.search(r"^\|\s*" + re.escape(label) + r"\s*\|\s*(.*?)\s*\|\s*$", text, re.M)
        data[key] = row.group(1) if row else None
    data["summary"] = _section(text, "Summary")
    keywords = _section(text, "Keywords")
    data["keywords"] = None if keywords is None else [k.strip() for k in keywords.split(";") if k.strip()]
    footer = re.search(r"Method:\s*(.*?)\s*\|\s*Status:\s*(.+?)\s*$", text, re.M)
    data["method"], data["status"] = (footer.group(1), footer.group(2)) if footer else ("", "")
    return data


def validate_file(path: Path, settings: dict) -> tuple:
    data = parse_summary_file(path)
    problems = []
    if not data["title"]:
        problems.append("Missing title line ('# <title>').")
    for key, label in TABLE_FIELDS:
        if data[key] is None:
            problems.append(f"Missing table row '{label}'.")
    if data["summary"] is None:
        problems.append("Missing '## Summary' section.")
    else:
        problems += check_summary(data, settings)
    if data["keywords"] is None:
        problems.append("Missing '## Keywords' section.")
    elif not 3 <= len(data["keywords"]) <= 5:
        problems.append(f"Use 3 to 5 keywords separated by ';' (found {len(data['keywords'])}).")
    return data, problems


def summary_files(output_dir: Path) -> list:
    return sorted(output_dir.rglob("*_summary.md"))


def write_index(settings: dict) -> Path:
    output_dir = ROOT / settings["output_dir"]
    index = output_dir / "summaries_index.csv"
    columns = ["file", "title", "source_file", "issuing_body", "country_or_region", "year",
               "document_type", "word_count", "summary", "keywords", "method", "status"]
    with open(index, "w", encoding="utf-8-sig", newline="") as fh:  # utf-8-sig opens cleanly in Excel
        writer = csv.DictWriter(fh, fieldnames=columns)
        writer.writeheader()
        for path in summary_files(output_dir):
            data = parse_summary_file(path)
            data["word_count"] = word_count(data["summary"] or "")
            data["keywords"] = "; ".join(data["keywords"] or [])
            writer.writerow({c: data.get(c) or "" for c in columns})
    return index


# ----------------------------------------------------------------------------- pipeline

def parse_json_object(text: str) -> dict:
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", text, re.S)
        if not match:
            raise ValueError("no JSON object in the response")
        data = json.loads(match.group(0))
    if not isinstance(data, dict):
        raise ValueError("the response is not a JSON object")
    return data


def ask_json(client: OllamaClient, agent: Agent, prompt: str, context: str) -> dict:
    last_error = None
    for attempt in range(2):
        suffix = "" if attempt == 0 else "\n\nYour previous answer was not valid JSON. Return exactly one JSON object."
        text = client.chat(agent, prompt + suffix, context=context, schema=SUMMARY_SCHEMA)
        try:
            return normalise(parse_json_object(text))
        except (ValueError, json.JSONDecodeError) as exc:
            last_error = exc
            log.warning("  %s returned invalid JSON (%s), retrying", agent.name, exc)
    raise RuntimeError(f"Agent '{agent.name}' did not return valid JSON: {last_error}")


def relative_to_input(pdf: Path, settings: dict) -> Path:
    input_dir = (ROOT / settings["input_dir"]).resolve()
    pdf = pdf.resolve()
    return pdf.relative_to(input_dir) if pdf.is_relative_to(input_dir) else Path(pdf.name)


def extract_document(pdf: Path, settings: dict) -> tuple:
    raw, extractor = extract_pdf_text(pdf)
    text = clean_text(raw)
    target = ROOT / settings["work_dir"] / "extracted" / relative_to_input(pdf, settings).with_suffix(".txt")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text, encoding="utf-8")
    if len(text) < settings["min_text_chars"]:
        raise ScannedPdfError(
            f"only {len(text)} characters of text found - the PDF is probably scanned. "
            "Run OCR first, e.g. 'ocrmypdf input.pdf input_ocr.pdf'.")
    return text, extractor, target


def summarise_pdf(pdf: Path, settings: dict, agents: dict, client: OllamaClient) -> tuple:
    pipeline = settings["pipeline"]
    notes_agent = agents[pipeline["notes"]]
    summariser = agents[pipeline["summariser"]]
    reviewer = agents[pipeline["reviewer"]]
    context = pdf.name

    text, extractor, text_file = extract_document(pdf, settings)
    log.info("  extracted %d characters with %s -> %s", len(text), extractor, text_file.relative_to(ROOT))

    # Step 1: long documents are condensed into section notes first
    if len(text) <= settings["chunk_chars"]:
        label, source = "FULL DOCUMENT TEXT", text
    else:
        chunks = select_chunks(split_chunks(text, settings["chunk_chars"]), settings["max_chunks"])
        notes = []
        for i, chunk in enumerate(chunks, 1):
            log.info("  [%s] section %d/%d", notes_agent.name, i, len(chunks))
            prompt = f"Document: {pdf.name}\nSection {i} of {len(chunks)}:\n\n----- BEGIN SECTION -----\n{chunk}\n----- END SECTION -----"
            note = client.chat(notes_agent, prompt, context=context).strip()
            if note and "NO RELEVANT CONTENT" not in note.upper():
                notes.append(f"[Section {i}/{len(chunks)}]\n{note}")
        label = "TITLE PAGE EXCERPT AND SECTION NOTES"
        source = text[: settings["title_excerpt_chars"]] + "\n\n[Section notes]\n\n" + "\n\n".join(notes)

    # Step 2: structured draft
    log.info("  [%s] drafting summary (%s)", summariser.name, summariser.model)
    prompt = (f"Source file: {pdf.name}\n\n{label}:\n----- BEGIN SOURCE -----\n{source}\n----- END SOURCE -----\n\n"
              "Return the JSON object now.")
    best = ask_json(client, summariser, prompt, context)
    best_problems = check_summary(best, settings)
    log.info("  draft: %d words, %d issue(s)", word_count(best["summary"]), len(best_problems))

    # Step 3: review loop (agent revises, deterministic checks decide)
    mode = settings.get("review_mode", "always")
    rounds = 0
    while mode != "never" and rounds < settings["max_revisions"] and (best_problems or (mode == "always" and rounds == 0)):
        rounds += 1
        findings = "\n".join(f"- {p}" for p in best_problems) or "- None. Check neutrality, accuracy and format."
        prompt = (f"SOURCE ({label}, may be shortened):\n----- BEGIN SOURCE -----\n"
                  f"{source[: settings['review_source_chars']]}\n----- END SOURCE -----\n\n"
                  f"DRAFT JSON:\n{json.dumps(best, ensure_ascii=False, indent=2)}\n\n"
                  f"AUTOMATIC CHECK FINDINGS:\n{findings}\n\nReturn the corrected JSON object now.")
        log.info("  [%s] review round %d", reviewer.name, rounds)
        revised = ask_json(client, reviewer, prompt, context)
        revised_problems = check_summary(revised, settings)
        if len(revised_problems) <= len(best_problems):
            best, best_problems = revised, revised_problems
        log.info("  review %d: %d words, %d issue(s)", rounds, word_count(best["summary"]), len(best_problems))

    # Step 4: last resort for the hard word limit
    notes = []
    if word_count(best["summary"]) > settings["max_words"]:
        best["summary"] = truncate_words(best["summary"], settings["max_words"])
        best_problems = check_summary(best, settings)
        notes.append("summary truncated automatically")
    status = "OK" if not best_problems and not notes else "NEEDS HUMAN REVIEW - " + "; ".join(notes + best_problems)
    models = sorted({summariser.model, reviewer.model})
    method = f"Offline harness (Ollama {', '.join(models)})"
    return best, status, method


# ----------------------------------------------------------------------------- commands

def check_setup(settings: dict, agents: dict, client: OllamaClient) -> int:
    ok = True

    def report(passed: bool, message: str):
        nonlocal ok
        ok = ok and passed
        print(("[OK] " if passed else "[!!] ") + message)

    report(sys.version_info >= (3, 9), f"Python {platform_version()}")
    extractors = []
    for module in ("pypdf", "pdfplumber", "PyPDF2"):
        try:
            __import__(module)
            extractors.append(module)
        except ImportError:
            pass
    if shutil.which("pdftotext"):
        extractors.append("pdftotext")
    report(bool(extractors), "PDF text extractors: " + (", ".join(extractors) or "none - run: pip install pypdf"))
    for key in ("input_dir", "output_dir", "template"):
        report((ROOT / settings[key]).exists(), f"{key}: {settings[key]}")
    for role, name in settings["pipeline"].items():
        report(name in agents, f"agent for '{role}': {name}" + ("" if name in agents else " (missing in agents/)"))
    try:
        report(True, f"Ollama {client.version()} at {client.host}")
        available = client.models()
        for model in sorted({a.model for a in agents.values()}):
            present = client.has_model(model, available)
            report(present, f"model {model}" + ("" if present else f" missing - run: ollama pull {model}"))
    except ConnectionError as exc:
        report(False, str(exc))
    print("\nSetup is ready." if ok else "\nPlease fix the items marked [!!].")
    return 0 if ok else 1


def platform_version() -> str:
    return ".".join(map(str, sys.version_info[:3]))


def validate_outputs(settings: dict) -> int:
    files = summary_files(ROOT / settings["output_dir"])
    if not files:
        print(f"No *_summary.md files in {settings['output_dir']}/")
        return 0
    failed = 0
    for path in files:
        data, problems = validate_file(path, settings)
        words = word_count(data["summary"] or "")
        print(f"{'[OK]' if not problems else '[!!]'} {path.relative_to(ROOT)} ({words} words)")
        for problem in problems:
            print(f"     - {problem}")
        failed += bool(problems)
    index = write_index(settings)
    print(f"\n{len(files) - failed}/{len(files)} summaries passed. Index: {index.relative_to(ROOT)}")
    return 1 if failed else 0


def find_pdfs(args, settings: dict) -> list:
    if args.file:
        return [Path(f).resolve() for f in args.file]
    input_dir = ROOT / settings["input_dir"]
    return sorted(p for p in input_dir.rglob("*") if p.is_file() and p.suffix.lower() == ".pdf")


def setup_logging(log_file: Path | None, verbose: bool):
    handlers = [logging.StreamHandler(sys.stdout)]
    if log_file:
        handlers.append(logging.FileHandler(log_file, encoding="utf-8"))
    logging.basicConfig(level=logging.DEBUG if verbose else logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(message)s", datefmt="%H:%M:%S", handlers=handlers)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Summarise TVET policy PDFs with local agents (Ollama).")
    parser.add_argument("--file", nargs="+", help="PDF file(s) to summarise (default: all PDFs in input/)")
    parser.add_argument("--model", help="use this Ollama model for all agents")
    parser.add_argument("--force", action="store_true", help="overwrite existing summaries")
    parser.add_argument("--extract-only", action="store_true", help="only extract text to work/extracted/")
    parser.add_argument("--validate", action="store_true", help="validate summaries in output/ and rebuild the index")
    parser.add_argument("--check", action="store_true", help="check the setup")
    parser.add_argument("--list-agents", action="store_true", help="list agent definitions")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args(argv)

    settings = load_settings()
    for key in ("input_dir", "output_dir", "work_dir", "log_dir"):
        (ROOT / settings[key]).mkdir(parents=True, exist_ok=True)
    agents = load_agents(settings)
    if args.model:
        for agent in agents.values():
            agent.model = args.model

    if args.list_agents:
        for agent in agents.values():
            print(f"{agent.name:<18} role={agent.role:<11} model={agent.model:<16} output={agent.output:<5} {agent.description}")
        return 0
    if args.validate:
        return validate_outputs(settings)

    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    log_dir = ROOT / settings["log_dir"]
    client = OllamaClient(settings["ollama_host"], settings["request_timeout_s"], log_dir / f"run_{stamp}_agents.jsonl")
    if args.check:
        return check_setup(settings, agents, client)

    setup_logging(log_dir / f"run_{stamp}.log", args.verbose)
    pdfs = find_pdfs(args, settings)
    if not pdfs:
        log.warning("No PDF files found in %s/ - copy policy PDFs there and run again.", settings["input_dir"])
        return 0

    if args.extract_only:
        for pdf in pdfs:
            try:
                text, extractor, target = extract_document(pdf, settings)
                log.info("[OK] %s -> %s (%d characters, %s)", pdf.name, target.relative_to(ROOT), len(text), extractor)
            except Exception as exc:
                log.error("[!!] %s: %s", pdf.name, exc)
        return 0

    missing_agents = [n for n in settings["pipeline"].values() if n not in agents]
    if missing_agents:
        log.error("Agent definition(s) not found in agents/: %s", ", ".join(missing_agents))
        return 2
    try:
        available = client.models()
    except ConnectionError as exc:
        log.error(str(exc))
        return 2
    needed = sorted({agents[n].model for n in settings["pipeline"].values()})
    missing = [m for m in needed if not client.has_model(m, available)]
    if missing:
        log.error("Model(s) not installed: %s. Run: %s", ", ".join(missing),
                  " && ".join(f"ollama pull {m}" for m in missing))
        return 2

    done, skipped, failed, review = 0, 0, 0, 0
    for number, pdf in enumerate(pdfs, 1):
        out = ROOT / settings["output_dir"] / relative_to_input(pdf, settings).parent / f"{pdf.stem}_summary.md"
        if out.exists() and not args.force:
            log.info("(%d/%d) skip %s - summary exists (use --force)", number, len(pdfs), pdf.name)
            skipped += 1
            continue
        log.info("(%d/%d) %s", number, len(pdfs), pdf.name)
        started = time.time()
        try:
            data, status, method = summarise_pdf(pdf, settings, agents, client)
        except Exception as exc:
            log.error("  FAILED: %s", exc)
            failed += 1
            continue
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(render_summary(data, settings, pdf.name, method, status), encoding="utf-8")
        done += 1
        review += status != "OK"
        log.info("  -> %s | %d words | %s | %.0fs", out.relative_to(ROOT), word_count(data["summary"]), status, time.time() - started)

    index = write_index(settings)
    log.info("Finished: %d summarised (%d need human review), %d skipped, %d failed. Index: %s",
             done, review, skipped, failed, index.relative_to(ROOT))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
