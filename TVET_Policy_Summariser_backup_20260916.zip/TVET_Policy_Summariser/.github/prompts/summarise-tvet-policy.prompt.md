---
description: Summarise TVET policy PDFs from input/ in the standard 80-word format
agent: agent
---
Summarise the following TVET policy document(s): ${input:documents:all PDFs in input/ without a summary in output/}

Follow [the repository instructions](../copilot-instructions.md) exactly:

1. Use the extracted text in `work/extracted/`. If it is missing, run `./run.sh --extract-only` (Windows: `run.bat --extract-only`).
2. Write one summary per document: neutral, third person, English, one paragraph, maximum 80 words.
3. Save each summary as `output/<pdf name>_summary.md` in the exact output format.
4. Run `./run.sh --validate` and fix all problems.
5. Report a table: file, word count, validation result.
