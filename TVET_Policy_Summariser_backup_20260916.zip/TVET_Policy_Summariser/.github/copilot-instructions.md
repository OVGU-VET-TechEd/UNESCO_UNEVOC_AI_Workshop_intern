# Copilot instructions: TVET policy summaries

This repository produces standardised summaries of Technical and Vocational Education and Training (TVET) policy documents.
PDF files are in `input/`. Summaries are saved in `output/`. All summaries must follow the house style and output format below exactly.

## Workflow for summarising a policy document
1. Get the document text. PDFs cannot always be read directly: use `work/extracted/<pdf name>.txt`.
   If the file does not exist, run `./run.sh --extract-only` (Windows: `run.bat --extract-only`).
2. Read the whole text. Identify title, issuing body, country or region, year and document type.
3. Write the summary following the house style.
4. Save it as `output/<pdf name without .pdf>_summary.md` using exactly the output format below.
5. Validate with `./run.sh --validate` (Windows: `run.bat --validate`) and fix every reported problem.

## House style

### Format
- Length: maximum 80 words (hard limit). Aim for 60 to 80 words.
- One paragraph of continuous prose. No bullet points, headings, quotations or line breaks.
- Language: English. Translate content from documents written in other languages.

### Content (in this order)
1. What the document is: document type, issuing body, country or region, year.
2. Its main purpose or objective.
3. The key measures, instruments or reforms.
4. The main target groups and, if stated, the timeframe or quantified targets.

### Style
- Neutral and factual. Describe; do not evaluate.
- Third person and present tense: "The strategy aims to ...", "The act establishes ...".
- Attribute intentions and claims to the document: "The policy states ...", "It plans to ...".
- No evaluative or promotional words (e.g. excellent, ambitious, innovative, successful, weak, unfortunately, clearly).
- No recommendations, opinions, speculation or information from outside the document.
- No first or second person (I, we, our, you).
- Write out abbreviations at first use, except TVET (Technical and Vocational Education and Training).
- Keep names, numbers and dates exactly as in the document.

### Recommended opening
"The [year] [document type] by [issuing body] ([country or region]) ..." - leave out elements that are not stated.

### Example (fictional document)
The 2024 National TVET Strategy by the Ministry of Labour of Examplestan sets out a framework to align vocational training with labour market needs. It introduces a competency-based qualifications framework, expands work-based learning with employers and creates a national TVET quality assurance agency. The strategy targets young people, adult workers and women in rural areas and sets a target of 50,000 apprenticeships by 2030.

## Output format

Replace every `<...>` placeholder. Use "Not stated" for unknown metadata. Keep the headings, the table rows and the footer line exactly as shown.

```markdown
# <Official document title>

| Field | Value |
|---|---|
| Source file | <file name>.pdf |
| Issuing body | <Issuing organisation or ministry, or Not stated> |
| Country/Region | <Country, region or International, or Not stated> |
| Year | <YYYY or Not stated> |
| Document type | <Policy / Strategy / Act / Regulation / Action plan / Framework / Report / Guideline> |

## Summary

<One paragraph, max. 80 words>

## Keywords

<keyword 1>; <keyword 2>; <keyword 3>

---

Word count: <n>/80 | Generated: <YYYY-MM-DD> | Method: GitHub Copilot (<model name>) | Status: OK
```

## Do not
- Do not modify or delete files in `input/`.
- Do not add sections, bullet points or comments to summaries.
- Do not use knowledge from outside the document.
- Do not exceed 80 words in the summary paragraph. Count the words before saving.
