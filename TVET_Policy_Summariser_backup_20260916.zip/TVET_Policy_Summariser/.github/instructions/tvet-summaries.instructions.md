---
applyTo: "output/**/*.md"
---
Files in `output/` are TVET policy summaries. When creating or editing them:
- Keep the exact output format from `.github/copilot-instructions.md` (title, metadata table, Summary, Keywords, footer).
- The summary paragraph has at most 80 words, neutral wording, third person, English.
- Use 3 to 5 keywords separated by semicolons.
- Run `./run.sh --validate` after changes.
